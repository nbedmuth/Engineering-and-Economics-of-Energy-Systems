clc
clear all
%% Question c
m = readtable('energy_market_offers.csv');
k=1;
c=1;
pair_false=[];
pair_true=[];
for i =1:height(m)
    if m{i,4}=="False"
       array1(k,:)=table2array(m(i,5:24));
       k=k+1;
    elseif m{i,4}=="True"
       array2(c,:)=table2array(m(i,5:24));
       c=c+1;
    end
end

for j = 1:10   
    pair_false=[pair_false; array1(:, [j j+10])];
    pair_true=[pair_true; array2(:, [j j+10])];
    
end 


pair_false=sortrows(pair_false,2);

        
sum_false=grpstats(pair_false(:,1),pair_false(:,2),{@sum}); 

results_false=unique(pair_false(:,2));
results_false=results_false(~isnan(results_false));

f=[sum_false results_false];


f(1,1)=5;
fal=f;
for i = 2:(length(f))
    j=i-1;
    f(i,1)=f(i,1) + f(j,1);
end





% True cases
c = 1;


for i = 1:3712
    counter = 0;
    for j = 1:10
        if ~isnan(array2(i,j))
            counter = counter + 1;
        end
    end

    pairs = 1;

    for j = 1:10
        if pairs < counter && counter > 1
            if ~isnan(array2(i,j))
                t(c,1) = array2(i,j);
                t(c,3) = array2(i,j+10);
                for k = j+1:10
                    if ~isnan(array2(i,k))
                        t(c,2) = array2(i,k);
                        t(c,4) = array2(i,k+10);
                    end
                    break;
                end
                pairs = pairs + 1;
                c= c+1;
            end
   
        elseif counter == 1
            
            if ~isnan(array2(i,j))
                t(c,1) = array2(i,j);
                t(c,3) = array2(i,j+10);
                t(c,2) = 0;
                t(c,4) = 0;
                c = c+1;
            end
        end
    end
end

t2 = sortrows(t, 3);
uniqueval = unique(t2(:,3));
new=zeros(length(uniqueval),2);

j = 1;
c = t2(1,3);
real = t2(1,3);
k = 1;

while(t2(j,3) == c && j<length(t2))
    if real ~= c
        k = k+1;
        real = c;
    end
    
    new(k,1) = new(k,1) + t2(j,1);
    j = j+1;
    c = t2(j,3);
end
 
new(:,2) = uniqueval;
new(1083, 1) = 3204;
j = 1;

for i = 1:1083
    pi1 = new(i,2);

    while t2(j,3) == pi1 && t2(j,2) ~= 0
        pi2 = t(j,4);
           for k=i+1:length(new)
               if pi2> new(k,2)
                    y = value(t2(j,3),pi2,t2(j,1),t2(j,2),new(k,2));
                    new(k,1) = new(k,1) + y;
                else

                    break;
               end
           end
        j = j+1;
    end
end
new1=new;
for i=1:length(new)-1
    new(i+1,1)=new(i+1,1)+new(i,1);
end 



ff=fal;
tt=new1;
for i=1:length(tt)-1
    for j=1:length(ff)
        if ff(j,2)>tt(i,2) && ff(j,2)<tt(i+1,2)
           y=value(tt(i,2),tt(i+1,2),tt(i,1),tt(i+1,1),ff(j,2));
           tt=[tt;[y, ff(j,2)]];    
        elseif ff(j,2)>tt(i+1,2)
            break
        end
    end
end

for i= 1:length(ff)-1
    for j = 1:length(tt)
        if tt(j,2)>ff(i,2) && tt(j,2)<ff(i+1,2)
            tt(j,1) = tt(j,1) + ff(i,1);
        elseif tt(j,2) == ff(i+1,2)
            tt(j,1) = tt(j,1) + ff(i,1);
            tt = [tt;[ff(i+1,1)+tt(j,1), ff(i+1,2)]];
        end
    end
end

for j=1:3
    tt=[tt;[fal(j,1), fal(j,2)]];

end
tt=sortrows(tt,2) ;

for i = 2:(length(tt))
    j=i-1;
    tt(i,1)=tt(i,1) +tt(j,1);
end
    

figure
subplot(2,1,1);
plot(tt(:,1),tt(:,2)) ;
xlabel('price');
ylabel('quantitiy');
subplot(2,1,2);
plot(tt(:,2),tt(:,1)) ;
xlabel('quantity');
ylabel('price');
function y = value(x1,x2,y1,y2,check)
    coefficients = polyfit([x1, x2], [y1, y2], 1);
    a = coefficients (1); 
    b = coefficients (2); 
    y = a*check + b;
end    
