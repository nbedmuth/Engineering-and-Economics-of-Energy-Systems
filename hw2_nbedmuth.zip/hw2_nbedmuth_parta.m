clc
clear all
m = readtable('energy_market_offers.csv');
k=1;
c=1;
pair_false=[];
pair_true=[];
for i =1:height(m)
    if m{i,4}=="False"
       array1(k,:)=table2array(m(i,5:24));
       k=k+1;
    elseif m{i,4}=="True"
       array2(c,:)=table2array(m(i,5:24));
       c=c+1;
    end
end

for j = 1:10   
    pair_false=[pair_false; array1(:, [j j+10])];
    pair_true=[pair_true; array2(:, [j j+10])];
    
end 


pair_false=sortrows(pair_false,2);

        
sum_false=grpstats(pair_false(:,1),pair_false(:,2),{@sum}); 

results_false=unique(pair_false(:,2));
results_false=results_false(~isnan(results_false));

f=[sum_false results_false];


f(1,1)=5;
fal=f;
for i = 2:(length(f))
    j=i-1;
    f(i,1)=f(i,1) + f(j,1);
end


figure
subplot(2,1,1);
stairs(f(:,1), f(:,2));
xlabel('price');
ylabel('quantitiy');
subplot(2,1,2);
stairs(f(:,2), f(:,1));
xlabel('quantity');
ylabel('price');

